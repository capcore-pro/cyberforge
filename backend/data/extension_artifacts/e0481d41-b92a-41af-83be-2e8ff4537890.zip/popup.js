const KEYS = {
  master: "cf_master_enabled",
  page: "cf_page_enabled",
  notif: "cf_notif_enabled",
  actions: "cf_stat_actions",
  pages: "cf_stat_pages",
  label: "cf_opt_label",
  delay: "cf_opt_delay",
};

async function load() {
  const data = await chrome.storage.local.get({
    [KEYS.master]: true,
    [KEYS.page]: true,
    [KEYS.notif]: false,
    [KEYS.actions]: 0,
    [KEYS.pages]: 0,
    [KEYS.label]: "",
    [KEYS.delay]: 300,
  });
  document.getElementById("toggleMaster").checked = data[KEYS.master];
  document.getElementById("togglePage").checked = data[KEYS.page];
  document.getElementById("toggleNotif").checked = data[KEYS.notif];
  document.getElementById("statActions").textContent = String(data[KEYS.actions]);
  document.getElementById("statPages").textContent = String(data[KEYS.pages]);
  if (data[KEYS.label]) {
    document.getElementById("optLabel").value = data[KEYS.label];
  }
  document.getElementById("optDelay").value = String(data[KEYS.delay]);
  syncToBackground();
}

async function save(partial) {
  await chrome.storage.local.set(partial);
  syncToBackground();
}

function syncToBackground() {
  chrome.runtime.sendMessage({ type: "cf_sync_state" }).catch(() => {});
}

document.getElementById("toggleMaster").addEventListener("change", (e) => {
  save({ [KEYS.master]: e.target.checked });
});
document.getElementById("togglePage").addEventListener("change", (e) => {
  save({ [KEYS.page]: e.target.checked });
});
document.getElementById("toggleNotif").addEventListener("change", (e) => {
  save({ [KEYS.notif]: e.target.checked });
});
document.getElementById("btnSettings").addEventListener("click", () => {
  document.getElementById("settingsPanel").classList.toggle("open");
});
document.getElementById("btnApply").addEventListener("click", async () => {
  const label = document.getElementById("optLabel").value.trim();
  const delay = parseInt(document.getElementById("optDelay").value, 10) || 0;
  await save({ [KEYS.label]: label, [KEYS.delay]: delay });
  const actions = (await chrome.storage.local.get({ [KEYS.actions]: 0 }))[KEYS.actions];
  await save({ [KEYS.actions]: actions + 1 });
  document.getElementById("statActions").textContent = String(actions + 1);
});

load();
