const DEFAULTS = {
  cf_master_enabled: true,
  cf_page_enabled: true,
  cf_notif_enabled: false,
  cf_stat_actions: 0,
  cf_stat_pages: 0,
};

chrome.runtime.onInstalled.addListener(async () => {
  const cur = await chrome.storage.local.get(DEFAULTS);
  await chrome.storage.local.set({ ...DEFAULTS, ...cur });
  console.log("[CyberForge] extension installed");
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "cf_sync_state") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0] && tabs[0].id;
      if (tabId != null) {
        chrome.tabs.sendMessage(tabId, { type: "cf_apply_state" }).catch(() => {});
      }
      sendResponse({ ok: true });
    });
    return true;
  }
  if (msg && msg.type === "cf_page_visit") {
    chrome.storage.local.get({ cf_stat_pages: 0 }, (data) => {
      chrome.storage.local.set({ cf_stat_pages: (data.cf_stat_pages || 0) + 1 });
    });
    sendResponse({ ok: true });
  }
  return false;
});
