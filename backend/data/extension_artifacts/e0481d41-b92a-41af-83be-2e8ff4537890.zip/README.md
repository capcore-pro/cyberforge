# TYPE: extension_navigateur Extension Chrome pour bloquer les

Extension Chrome Manifest V3 générée par CyberForge.

## Installation
1. Ouvrir `chrome://extensions`
2. Activer **Mode développeur**
3. **Charger l'extension non empaquetée**
4. Sélectionner ce dossier (fichiers dézippés)

## Fichiers
- `manifest.json` — configuration MV3
- `popup.html` / `popup.js` — interface popup 380×500
- `background.js` — service worker
- `content.js` — script injecté sur les pages
