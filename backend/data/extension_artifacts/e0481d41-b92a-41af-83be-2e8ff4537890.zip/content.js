async function readState() {
  return chrome.storage.local.get({
    cf_master_enabled: true,
    cf_page_enabled: true,
    cf_notif_enabled: false,
    cf_opt_delay: 300,
  });
}

function applyVisual(enabled) {
  if (!enabled) {
    document.documentElement.style.filter = "";
    document.documentElement.removeAttribute("data-cf-extension");
    return;
  }
  document.documentElement.setAttribute("data-cf-extension", "on");
  document.documentElement.style.outline = "2px solid rgba(79, 70, 229, 0.35)";
}

async function applyFromStorage() {
  const state = await readState();
  const on = Boolean(state.cf_master_enabled && state.cf_page_enabled);
  applyVisual(on);
  if (on) {
    chrome.runtime.sendMessage({ type: "cf_page_visit" }).catch(() => {});
  }
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "cf_apply_state") {
    applyFromStorage();
  }
});

applyFromStorage();
